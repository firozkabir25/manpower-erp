

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">Add Foreign Agent</div>
    <div class="card-body">
        <form action="<?php echo e(route('foreign-agents.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('admin.master_info.foreign_agents.form', ['agent' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <button type="submit" class="btn btn-success">Save</button>
        </form>
    </div>
</div>


<div class="modal fade" id="ledgerModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content" id="ledgerModalContent"></div>
    </div>
</div>

<script>
function openLedgerPopup() {
    fetch("<?php echo e(route('ledger.search')); ?>")
        .then(res => res.text())
        .then(html => {
            document.getElementById("ledgerModalContent").innerHTML = html;
            new bootstrap.Modal(document.getElementById('ledgerModal')).show();
        });
}

function selectLedger(id, name) {
    document.getElementById("ledger_id").value = id;
    document.getElementById("ledger_name").value = name;
    bootstrap.Modal.getInstance(document.getElementById('ledgerModal')).hide();
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\php82\htdocs\erp - Copy\resources\views/admin/master_info/foreign_agents/create.blade.php ENDPATH**/ ?>