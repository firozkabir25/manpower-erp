

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Create Expense</h3>

    <form action="<?php echo e(route('expenses.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label>Name *</label>
            <input type="text" name="name" class="form-control" required>
        </div>

        

        <div class="mb-3">
            <label>Sort *</label>
            <input type="number" step="0.1" name="sort" value="0.0" class="form-control" required>
        </div>

        <button class="btn btn-primary">Save</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\php82\htdocs\erp - Copy\resources\views/admin/master_info/expenses/create.blade.php ENDPATH**/ ?>