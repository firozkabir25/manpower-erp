

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Expense List</h3>

    <a href="<?php echo e(route('expenses.create')); ?>" class="btn btn-primary mb-3">
        Add New
    </a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>User</th>
                <th>Active</th>
                <th>Sort</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e(optional($item->user)->name ?? $item->user_id); ?></td>
                <td>
                    <a href="<?php echo e(route('expenses.toggle.active', $item->id)); ?>"
                       class="btn btn-sm <?php echo e($item->active == '1' ? 'btn-success' : 'btn-secondary'); ?>">
                        <?php echo e($item->active == '1' ? 'Active' : 'Inactive'); ?>

                    </a>
                </td>
                <td><?php echo e($item->sort); ?></td>
                <td>
                    <a href="<?php echo e(route('expenses.edit', $item->id)); ?>" class="btn btn-warning btn-sm">
                        Edit
                    </a>

                    <form action="<?php echo e(route('expenses.destroy', $item->id)); ?>" method="POST"
                          style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button onclick="return confirm('Delete?')" class="btn btn-danger btn-sm">
                            Delete
                        </button>
                    </form>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\php82\htdocs\erp - Copy\resources\views/admin/master_info/expenses/index.blade.php ENDPATH**/ ?>