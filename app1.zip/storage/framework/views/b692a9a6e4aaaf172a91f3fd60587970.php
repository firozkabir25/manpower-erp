
<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <div class=" d-flex justify-content-between align-items-center">
            <div>
                <h3 class="card-title">All Licences</h3>
            </div>
            <div>
                <a href="<?php echo e(route('licence.create')); ?>" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Add New</a>
            </div>
        </div>
    </div>

    <div class="card-body table-responsive p-0">
        <table class="table table-hover text-nowrap">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Licence</th>
                    <th>RL No</th>
                    <th>User</th>
                    <th>Address</th>
                    
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $licences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $licence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($licence->id); ?></td>
                    <td><?php echo e($licence->licence); ?></td>
                    <td><?php echo e($licence->rlno); ?></td>
                    <td><?php echo e($licence->user?->name); ?></td>
                    <td><?php echo e($licence->address); ?></td>
                    
                    <td class="text-center">
                        <a href="<?php echo e(route('licence.edit', $licence->id)); ?>" class="btn btn-sm btn-info">
                            <i class="fas fa-edit"></i>edit
                        </a>
                        <form action="<?php echo e(route('licence.destroy', $licence->id)); ?>" method="POST" class="d-inline"
                              onsubmit="return confirm('Are you sure you want to delete this item?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger">
                                <i class="fas fa-trash"></i>delete
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center">No data found</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="card-footer clearfix">
        <?php echo e($licences->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\php82\htdocs\erp - Copy\resources\views/admin/master_info/licence/index.blade.php ENDPATH**/ ?>