

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Add Status</h3>

    <form action="<?php echo e(route('status.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label>Status Name *</label>
            <input type="text" name="name" class="form-control" required>
        </div>

        <div class="form-group mt-2">
            <label>Sort</label>
            <input type="number" step="0.0001" name="sort" class="form-control">
        </div>

        <button class="btn btn-success mt-3">Save</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\php82\htdocs\erp - Copy\resources\views/admin/master_info/status/create.blade.php ENDPATH**/ ?>