<div class="modal-header">
    <h5 class="modal-title">Select Ledger</h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">
    <table class="table table-bordered table-hover">
        <thead>
            <tr>
                <th>ID</th>
                <th>Ledger Name</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $ledgers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ledger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr onclick="selectLedger(<?php echo e($ledger->id); ?>, '<?php echo e($ledger->ledger); ?>')" style="cursor:pointer;">
                <td><?php echo e($ledger->id); ?></td>
                <td><?php echo e($ledger->ledger); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH D:\php82\htdocs\erp - Copy\resources\views/admin/master_info/foreign_agents/ledger_search.blade.php ENDPATH**/ ?>