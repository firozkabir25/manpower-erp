<div class="form-group">
    <label>Name *</label>
    <input type="text" name="name" value="<?php echo e(old('name', $agent?->name ?? '')); ?>" class="form-control" required>
</div>

<div class="form-group">
    <label>Country</label>
    <select name="country_id" class="form-control">
        <option value="">-- Select Country --</option>
        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($country->id); ?>"
                <?php echo e(old('country_id', $agent?->country_id ?? '') == $country->id ? 'selected' : ''); ?>>
                <?php echo e($country->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
    <label>Email *</label>
    <input type="email" name="email" value="<?php echo e(old('email', $agent?->email ?? '')); ?>" class="form-control" required>
</div>

<div class="form-group">
    <label>Phone *</label>
    <input type="text" name="phone" value="<?php echo e(old('phone', $agent?->phone ?? '')); ?>" class="form-control" required>
</div>

<div class="form-group">
    <label>Address</label>
    <textarea name="address" class="form-control" rows="3"><?php echo e(old('address', $agent?->address ?? '')); ?></textarea>
</div>

<div class="form-group">
    <label>User *</label>
    <input type="hidden" name="user_id" value="<?php echo e(old('user_id', $agent?->user_id ?? auth()->id())); ?>">
    <input type="text" class="form-control" value="<?php echo e($agent?->user?->name ?? auth()->user()?->name ?? auth()->id()); ?>" readonly>
</div>

<div class="form-group">
    <label>Ledger *</label>
    <div class="input-group">
         <input type="hidden" name="ledger_id" id="ledger_id"
             value="<?php echo e(old('ledger_id', $agent?->ledger_id ?? '')); ?>">

         <input type="text" id="ledger_name"
             value="<?php echo e(old('ledger_name', $agent?->ledger?->ledger ?? '')); ?>"
               class="form-control"
               placeholder="Select Ledger"
               readonly>

        <button type="button" class="btn btn-primary" onclick="openLedgerPopup()">
            <i class="fa fa-search"></i>
        </button>
    
</div>
<?php /**PATH D:\php82\htdocs\erp - Copy\resources\views/admin/master_info/foreign_agents/form.blade.php ENDPATH**/ ?>