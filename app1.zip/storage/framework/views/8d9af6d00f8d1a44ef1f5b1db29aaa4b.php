

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 class="mb-3">Airlines</h3>

    <a href="<?php echo e(route('airline.create')); ?>" class="btn btn-primary mb-3">
        + Add Airline
    </a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Code</th>
                <th>Created By</th>
                <th width="160">Actions</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $airlines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($airline->name); ?></td>
                    <td><?php echo e($airline->code); ?></td>
                    <td><?php echo e($airline->user->name ?? 'N/A'); ?></td>

                    <td>
                        <a href="<?php echo e(route('airline.edit', $airline->id)); ?>"
                           class="btn btn-sm btn-info">Edit</a>

                        <form action="<?php echo e(route('airline.destroy', $airline->id)); ?>"
                              method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button class="btn btn-sm btn-danger"
                                    onclick="return confirm('Delete this airline?')">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>

    <?php echo e($airlines->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\php82\htdocs\erp - Copy\resources\views/admin/master_info/airlines/index.blade.php ENDPATH**/ ?>