

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Companies</h1>

    <!-- Add Company Button -->
    <a href="<?php echo e(route('company.create')); ?>" class="btn btn-primary mb-3">Add Company</a>

    <!-- Success Message -->
    

    <!-- Companies Table -->
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Short Name</th>
                <th>Arabic Name</th>
                <th>Country</th>
                <th>ID Number</th>
                <th>Contact By</th>
                <th>Address</th>
                <th>Email</th>
                <th>Phone</th>
                <th>User</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($company->id); ?></td>
                <td><?php echo e($company->name); ?></td>
                <td><?php echo e($company->short_name); ?></td>
                <td><?php echo e($company->name_arabic); ?></td>
                <td><?php echo e($company->country?->name ?? '-'); ?></td>
                <td><?php echo e($company->id_number); ?></td>
                <td><?php echo e($company->contact_by ?? '-'); ?></td>
                <td><?php echo e($company->address ?? '-'); ?></td>
                <td><?php echo e($company->email); ?></td>
                <td><?php echo e($company->phone); ?></td>
                <td><?php echo e($company->user?->name ?? '-'); ?></td>
                <td>
                    <a href="<?php echo e(route('company.edit', $company)); ?>" class="btn btn-sm btn-warning mb-1">Edit</a>
                    <form action="<?php echo e(route('company.destroy', $company)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="11" class="text-center">No companies found.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\php82\htdocs\erp - Copy\resources\views/admin/master_info/companies/index.blade.php ENDPATH**/ ?>