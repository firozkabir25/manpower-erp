<!--begin::Footer-->
      <footer class="app-footer">
        <!--begin::To the end-->
        <div class="float-end d-none d-sm-inline">Anything you want</div>
        <!--end::To the end-->
        <!--begin::Copyright-->
        <strong>
          Copyright &copy; 2014-2025&nbsp;
          <a href="#" class="text-decoration-none">Legenda Soft</a>.
        </strong>
        All rights reserved.
        <!--end::Copyright-->
      </footer>
      <!--end::Footer--><?php /**PATH D:\php82\htdocs\erp - Copy\resources\views/partials/footer.blade.php ENDPATH**/ ?>