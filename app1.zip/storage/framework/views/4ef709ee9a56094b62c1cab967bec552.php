

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-2">
    <h3>Foreign Agents</h3>
    <a href="<?php echo e(route('foreign-agents.create')); ?>" class="btn btn-success">Add New</a>
</div>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Country</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Ledger ID</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($agent->name); ?></td>
                <td><?php echo e(optional($agent->country)->name ?? '--'); ?></td>
                <td><?php echo e($agent->email); ?></td>
                <td><?php echo e($agent->phone); ?></td>
                <td><?php echo e(optional($agent->ledger)->ledger ?? $agent->ledger_id); ?></td>
            <td>
                <a href="<?php echo e(route('foreign-agents.edit', $agent->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                <form action="<?php echo e(route('foreign-agents.destroy', $agent->id)); ?>" class="d-inline" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button onclick="return confirm('Delete?')" class="btn btn-danger btn-sm">Del</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php echo e($agents->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\php82\htdocs\erp - Copy\resources\views/admin/master_info/foreign_agents/index.blade.php ENDPATH**/ ?>