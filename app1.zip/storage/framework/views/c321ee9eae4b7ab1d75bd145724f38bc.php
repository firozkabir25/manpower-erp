

<?php $__env->startSection('content'); ?>
<div class="container">

    <h3>Currencies</h3>

    <a href="<?php echo e(route('currency.create')); ?>" class="btn btn-primary mb-3">
        + Add Currency
    </a>

    

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Currency</th>
                <th>Code</th>
                <th>Symbol</th>
                <th>Value</th>
                <th>Country</th>
                <th>Created By</th>
                <th width="150">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($currency->currency); ?></td>
                    <td><?php echo e($currency->currency_code); ?></td>
                    <td><?php echo e($currency->currency_symbol); ?></td>
                    <td><?php echo e($currency->_value); ?></td>
                    <td><?php echo e($currency->country->name ?? 'N/A'); ?></td>
                    <td><?php echo e($currency->user->name ?? 'N/A'); ?></td>

                    <td>
                        <a href="<?php echo e(route('currency.edit', $currency->id)); ?>"
                           class="btn btn-sm btn-info">Edit</a>

                        <form action="<?php echo e(route('currency.destroy', $currency->id)); ?>"
                              method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button class="btn btn-sm btn-danger"
                                    onclick="return confirm('Delete this record?')">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($currencies->links()); ?>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\php82\htdocs\erp - Copy\resources\views/admin/master_info/currencies/index.blade.php ENDPATH**/ ?>