

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Create Working Profession</h3>

    <form action="<?php echo e(route('working-professions.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label>Name *</label>
            <input type="text" name="name" class="form-control" required>
        </div>

        <div class="mb-3">
            <input type="hidden" name="user_id" value="<?php echo e(old('user_id', auth()->id())); ?>">
            <label>User</label>
            <input type="text" class="form-control" value="<?php echo e(auth()->user()->name ?? auth()->id()); ?>" readonly>
        </div>

        <button class="btn btn-primary">Save</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\php82\htdocs\erp - Copy\resources\views/admin/master_info/working_professions/create.blade.php ENDPATH**/ ?>