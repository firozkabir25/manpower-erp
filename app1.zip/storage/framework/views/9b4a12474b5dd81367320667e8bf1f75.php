

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Visa Profession List</h3>

    <a href="<?php echo e(route('visa-profession.create')); ?>" class="btn btn-primary mb-3">Add New</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Name (Arabic)</th>
                <th>User</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->namearabic); ?></td>
                <td><?php echo e(optional($item->user)->name ?? $item->user_id); ?></td>
                <td>
                    <a href="<?php echo e(route('visa-profession.edit', $item->id)); ?>" class="btn btn-sm btn-warning">Edit</a>

                    <form action="<?php echo e(route('visa-profession.destroy', $item->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Delete?')">Delete</button>
                    </form>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\php82\htdocs\erp - Copy\resources\views/admin/master_info/visaprofession/index.blade.php ENDPATH**/ ?>