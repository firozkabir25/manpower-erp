<div class="mb-3">
    <label>Name *</label>
    <input type="text" name="name" class="form-control"
           value="<?php echo e(old('name', $localagent->name ?? '')); ?>" required>
</div>

<div class="mb-3">
    <label>NID *</label>
    <input type="number" name="nid" class="form-control"
           value="<?php echo e(old('nid', $localagent->nid ?? '')); ?>" required>
</div>

<div class="mb-3">
    <label>Phone</label>
    <input type="text" name="phone" class="form-control"
           value="<?php echo e(old('phone', $localagent->phone ?? '')); ?>">
</div>

<div class="mb-3">
    <label>Email *</label>
    <input type="email" name="email" class="form-control"
           value="<?php echo e(old('email', $localagent->email ?? '')); ?>" required>
</div>

<div class="mb-3">
    <label>Address</label>
    <textarea name="address" class="form-control" rows="2"><?php echo e(old('address', $localagent->address ?? '')); ?></textarea>
</div>

<div class="mb-3">
    <label>Ledger</label>
    <select name="ledger_id" class="form-control">
        <option value="">Select Ledger</option>
        <?php $__currentLoopData = $ledgers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ledger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($ledger->id); ?>"
                <?php echo e(old('ledger_id', $localagent->ledger_id ?? '') == $ledger->id ? 'selected' : ''); ?>>
                <?php echo e($ledger->ledger); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="mb-3">
    <label>Code *</label>
    <input type="number" name="code" class="form-control"
           value="<?php echo e(old('code', $localagent->code ?? '')); ?>" required>
</div>
<?php /**PATH D:\php82\htdocs\erp - Copy\resources\views/admin/master_info/localagents/form.blade.php ENDPATH**/ ?>