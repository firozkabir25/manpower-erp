

<?php $__env->startSection('content'); ?>
<div class="container">

    <h3>Add Currency</h3>

    <form action="<?php echo e(route('currency.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <?php echo $__env->make('admin.master_info.currencies.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <button type="submit" class="btn btn-success mt-2">Save</button>
        <a href="<?php echo e(route('currency.index')); ?>" class="btn btn-secondary mt-2">Back</a>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\php82\htdocs\erp - Copy\resources\views/admin/master_info/currencies/create.blade.php ENDPATH**/ ?>