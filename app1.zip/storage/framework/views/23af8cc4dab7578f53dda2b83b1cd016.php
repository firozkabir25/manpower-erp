

<?php $__env->startSection('content'); ?>

<div class="container">
    <h3>Country List</h3>

    <a href="<?php echo e(route('country.create')); ?>" class="btn btn-primary mb-3">Add New</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Short</th>
                <th>Visa Days</th>
                <th>Police Days</th>
                <th>Medical Days</th>
                <th>Action</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($c->id); ?></td>
                <td><?php echo e($c->name); ?></td>
                <td><?php echo e($c->short); ?></td>
                <td><?php echo e($c->visa_expire_days); ?></td>
                <td><?php echo e($c->police_expire_days); ?></td>
                <td><?php echo e($c->medical_expire_days); ?></td>

                <td>
                    <a class="btn btn-warning btn-sm" href="<?php echo e(route('country.edit',$c->id)); ?>">Edit</a>

                    <form action="<?php echo e(route('country.destroy',$c->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button onclick="return confirm('Delete?')" class="btn btn-danger btn-sm">
                            Delete
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\php82\htdocs\erp - Copy\resources\views/admin/master_info/countries/index.blade.php ENDPATH**/ ?>